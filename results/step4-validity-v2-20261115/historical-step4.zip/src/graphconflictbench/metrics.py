"""Small smoke-slice scorer. Official statistical evaluation is out of scope."""

from .evidence_mapper import align_citations


def prf(predicted, expected):
    predicted, expected = set(predicted), set(expected)
    tp = len(predicted & expected)
    precision = tp / len(predicted) if predicted else 0.0
    recall = tp / len(expected) if expected else 0.0
    f1 = 2 * tp / (len(predicted) + len(expected)) if predicted or expected else 0.0
    return {"precision": precision, "recall": recall, "f1": f1}


def score_case(case, retrieval, prediction, documents, assertions):
    if prediction is None:
        return {
            "case_id": case.case_id,
            "outcome": "error",
            "localization_f1": 0.0,
            "exact_proof_set": False,
            "complete_proof_retrieved": False,
            "failure": "generation_error",
        }
    mapped, errors = align_citations(prediction, retrieval, documents, assertions)
    delivered = {a for i in retrieval.retrieved_items for a in i.mapped_assertion_ids}
    complete = any(set(p) <= delivered for p in case.gold_proof_sets) if case.gold_label else None
    outcome = (
        ("tp" if prediction.conflict_detected else "fn")
        if case.gold_label
        else ("fp" if prediction.conflict_detected else "tn")
    )
    loc = max((prf(mapped, p)["f1"] for p in case.gold_proof_sets), default=0.0)
    exact = any(set(mapped) == set(p) for p in case.gold_proof_sets) and not errors
    if outcome != "tp":
        loc, exact = 0.0, False
    failure = (
        "false_positive"
        if outcome == "fp"
        else "retrieval_incomplete"
        if case.gold_label and not complete
        else "post_retrieval_detection_miss"
        if outcome == "fn"
        else "localization_miss"
        if outcome == "tp" and not exact
        else None
    )
    return {
        "case_id": case.case_id,
        "outcome": outcome,
        "complete_proof_retrieved": complete,
        "localization_f1": loc,
        "exact_proof_set": exact,
        "mapped_citations": mapped,
        "citation_errors": errors,
        "failure": failure,
        "edge_mapping_scope": "verbatim_source_chunks_only",
    }


def aggregate(rows):
    counts = {k: sum(r["outcome"] == k for r in rows) for k in ("tp", "tn", "fp", "fn", "error")}
    tp, fp, fn = (counts[k] for k in ("tp", "fp", "fn"))
    # Error rows remain in total and valid-output rate; metric-specific denominators explicit.
    return {
        "cases": len(rows),
        **counts,
        "valid_output_rate": (len(rows) - counts["error"]) / len(rows) if rows else None,
        "precision": tp / (tp + fp) if tp + fp else None,
        "recall_valid_rows": tp / (tp + fn) if tp + fn else None,
        "f1_valid_rows": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None,
    }
