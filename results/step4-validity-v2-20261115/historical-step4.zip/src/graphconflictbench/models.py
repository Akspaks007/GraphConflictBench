"""Model providers. Fixture models test plumbing, never benchmark capability."""

import hashlib
import json
import os
import re

from .generator import NEGATIONS, PHRASES

STATEMENT = re.compile(
    r"(N[0-9a-f]{20}) (is not contained in|is contained in|"
    r"is not a subregion of|is a subregion of|does not precede|precedes) "
    r"(N[0-9a-f]{20})\."
)


def parse_statements(text):
    reverse = {v: (k, True) for k, v in PHRASES.items()}
    reverse.update({v: (k, False) for k, v in NEGATIONS.items()})
    return [
        (m.group(1), *reverse[m.group(2)], m.group(3), m.group()) for m in STATEMENT.finditer(text)
    ]


async def fixture_llm(prompt, system_prompt=None, history_messages=None, **kwargs):
    # Read only the text supplied to the native model callback, never the gold KG.
    if "---Input Text---" in prompt:
        text = prompt.split("---Input Text---", 1)[1].split("---Output---", 1)[0]
        entities, relations = {}, []
        for subject, pred, positive, obj, sentence in parse_statements(text):
            entities[subject] = (
                f"entity<|#|>{subject}<|#|>other<|#|>{subject} is a fictional entity."
            )
            entities[obj] = f"entity<|#|>{obj}<|#|>other<|#|>{obj} is a fictional entity."
            relations.append(f"relation<|#|>{subject}<|#|>{obj}<|#|>{pred}<|#|>{sentence}")
        return "\n".join([*entities.values(), *relations, "<|COMPLETE|>"])
    if kwargs.get("keyword_extraction") or "high_level_keywords" in prompt:
        # Native keyword prompt contains worked examples; use only its real query.
        query = prompt.rsplit("Real Data", 1)[-1]
        ids = list(dict.fromkeys(re.findall(r"N[0-9a-f]{20}", query)))
        return json.dumps({"high_level_keywords": list(PHRASES), "low_level_keywords": ids})
    if history_messages:
        return "<|COMPLETE|>"
    # Native description summarization only: preserve input statements verbatim.
    statements = [x[-1] for x in parse_statements(prompt)]
    return " ".join(dict.fromkeys(statements)) or "Fictional registry entity."


async def fixture_embedding(texts, dimension=256, **kwargs):
    import numpy as np

    values = np.zeros((len(texts), dimension), dtype=np.float32)
    for i, text in enumerate(texts):
        for token in re.findall(r"[a-z0-9_]+", text.lower()):
            hashed = hashlib.sha256(token.encode()).digest()
            values[i, int.from_bytes(hashed[:4], "big") % dimension] += 1
        norm = np.linalg.norm(values[i])
        if norm:
            values[i] /= norm
    return values


class OpenAIModels:
    def __init__(self, config):
        if not os.environ.get("OPENAI_API_KEY"):
            raise ValueError("OPENAI_API_KEY is required for provider=openai")
        from openai import AsyncOpenAI

        self.config = config
        self.client = AsyncOpenAI(max_retries=config.get("max_retries", 2), timeout=120)
        self.usage = []

    async def llm(self, prompt, system_prompt=None, history_messages=None, **kwargs):
        messages = [{"role": "system", "content": system_prompt}] if system_prompt else []
        messages.extend(history_messages or [])
        messages.append({"role": "user", "content": prompt})
        response = await self.client.chat.completions.create(
            model=self.config["llm_model"],
            messages=messages,
            temperature=0,
            **(
                {"response_format": {"type": "json_object"}}
                if kwargs.get("keyword_extraction")
                else {}
            ),
        )
        self.usage.append(
            {
                "kind": "llm",
                "model": response.model,
                "tokens": response.usage.model_dump() if response.usage else None,
            }
        )
        return response.choices[0].message.content or ""

    async def embedding(self, texts, **kwargs):
        import numpy as np

        response = await self.client.embeddings.create(
            model=self.config["embedding_model"],
            input=texts,
            dimensions=self.config["embedding_dimension"],
        )
        self.usage.append(
            {
                "kind": "embedding",
                "model": response.model,
                "tokens": response.usage.model_dump() if response.usage else None,
            }
        )
        return np.asarray(
            [x.embedding for x in sorted(response.data, key=lambda x: x.index)], dtype=np.float32
        )
