from pathlib import Path

from .manifests import canonical, digest
from .schemas import Prediction


def evidence_envelope(retrieval):
    return {
        "sources": [
            {"doc_id": i.doc_id, "text": i.text, "rank": i.rank} for i in retrieval.retrieved_items
        ],
        "native_graph": retrieval.native_graph,
    }


def build_prompt(case, retrieval, ontology, prompt_file):
    system = Path(prompt_file).read_text(encoding="utf-8")
    rules = [
        {
            "predicate": name,
            "transitive": rule.transitive,
            "irreflexive": rule.irreflexive,
            "explicit_negation": rule.allow_negation,
        }
        for name, rule in ontology.relations.items()
    ]
    payload = {
        "case_id": case.case_id,
        "question": case.query,
        "rules": rules,
        "evidence": evidence_envelope(retrieval),
        "response_schema": Prediction.model_json_schema(),
    }
    return system, canonical(payload), digest({"system": system, "payload": payload})
